#include <vector>
#include <string>
#include <iostream>
#include "token.h"
#include "scanner.h"

using namespace std;

class Parser {
 private:
  vector<Token> tokens;
  int currentTokenIndex = 0;
  TokenType currentTokenType = TokenType::END_OF_INPUT;
 public:
  Parser(const vector<Token>& tokens) : tokens(tokens) {
    currentTokenType = getNextTokenType();
  }
  TokenType tokenType() const {
    return currentTokenType;
  }
  void advanceToken() {
    currentTokenIndex++;
    currentTokenType = getNextTokenType();
  }
  void throwError() {
    cout << "error" << endl;
  }
  void match(TokenType t) {
    cout << "match: " << t << endl;
    if (currentTokenType == t) {
      // advance to the next token
      advanceToken();
    } else {
      // report a syntax error
      cout << "Syntax error: expected token type " << t << " but got " << currentTokenType << endl;
    }
  }

    void idList() {
        if (tokenType() == COMMA) {
            match(COMMA);
            match(ID);
            idList();
        } else {
            idList -> COMMA ID idList | lambda
        }
    }

    void scheme() {
        scheme -> ID LEFT_PAREN ID idList RIGHT_PAREN
    }
  TokenType getNextTokenType() {
    // code to get the next token
    if (currentTokenIndex >= tokens.size()) {
      // end of input, return a special token type indicating end of input
      return TokenType::END_OF_INPUT;
    }
    Token nextToken = tokens[currentTokenIndex];
    return nextToken.type;
  }
};
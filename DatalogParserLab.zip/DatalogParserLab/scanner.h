#pragma once
#include <iostream>
#include <string>
#include "token.h"

using namespace std;

class Scanner {
private:
    string input;
    int pos = 0;
    int lineNum;
    char currentChar;

public:
    Scanner(const string& input) : input(input), pos(0), lineNum(1) {
        currentChar = input[pos];
    }

    Token scanToken() {
        while (isspace(currentChar)) {
            if (currentChar == '\n') {
                lineNum++;
            }
            pos++;
            currentChar = input[pos];
        }
        if (currentChar == '#') {
            std::string comment;
            comment += currentChar;
            while (input[++pos] != '\n') {
                comment += input[pos];
                if (pos == input.size() - 1) {
                    return Token(COMMENT, comment, lineNum);
                }
            }
            comment += '\n';
            lineNum++;
            currentChar = input[++pos];
            return Token(COMMENT, comment, lineNum);
        }

        // Check for special characters
        switch (currentChar) {
            case ',':
                return Token(COMMA, ",", lineNum++);
            case '.':
                return Token(PERIOD, ".", lineNum++);
            case '?':
                return Token(Q_MARK, "?", lineNum++);
            case '(':
                return Token(LEFT_PAREN, "(", lineNum++);
            case ')':
                return Token(RIGHT_PAREN, ")", lineNum++);
            case ':':
                if (input[++pos] == '-') {
                    return Token(COLON_DASH, ":-", lineNum++);
                } else {
                    return Token(COLON, ":", lineNum++);
                }
            case '*':
                return Token(MULTIPLY, "*", lineNum++);
            case '+':
                return Token(ADD, "+", lineNum++);
        }

        // Check for strings (SCHEMES, FACTS, RULES, QUERIES)
        if(pos + 1 == input.size()){
            return Token (E_OF,"",lineNum);
        }

        if (isalpha(currentChar)) {
            std::string str;
            str += currentChar;
            while (isalnum(input[++pos])) {
                str += input[pos];
            }
            if (str == "SCHEMES") {

                return Token(SCHEMES, "SCHEMES", lineNum);
            } else if (str == "FACTS") {

                return Token(FACTS, "FACTS", lineNum);
            } else if (str == "RULES") {

                return Token(RULES, "RULES", lineNum);
            } else if (str == "QUERIES") {

                return Token(QUERIES, "QUERIES", lineNum);
            } else if (str == "ID"){

                return Token(ID, str, lineNum);
            } else if (str == "COMMENT"){

                return Token(COMMENT, str, lineNum);
            } else if (str == "$") {

                return Token(UNDEFINED, str, lineNum);
            } else {

                return Token(E_OF, str, lineNum);
            }
        }
    }
};


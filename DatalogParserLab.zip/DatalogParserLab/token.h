#pragma once

#include <sstream>
enum TokenType {
  COMMA,
  PERIOD,
  Q_MARK,
  LEFT_PAREN,
  RIGHT_PAREN,
  COLON,
  COLON_DASH,
  MULTIPLY,
  ADD,
  SCHEMES,
  FACTS,
  RULES,
  QUERIES,
  ID,
  COMMENT,
  UNDEFINED,
  END_OF_INPUT
};

class Token {
private:
  std::string value; // for INTEGER tokens
  int lineNum;

public:
  TokenType type;
  Token(TokenType type, std::string value, int lineNum)
      : type(type), value(value), lineNum(lineNum) {}

  std::string typeName() const {
    switch (type) {
      case COMMA:
        return "COMMA";
      case PERIOD:
        return "PERIOD";
      case Q_MARK:
        return "Q MARK";
      case LEFT_PAREN:
        return "L PAREN";
      case RIGHT_PAREN:
        return "R PAREN";
      case COLON:
        return "COLON";
      case COLON_DASH:
        return "COLON DASH";
      case MULTIPLY:
        return "MUL";
      case ADD:
        return "ADD";
      case SCHEMES:
        return "SCHEMES";
      case FACTS:
        return "FACTS";
      case RULES:
        return "RULES";
      case QUERIES:
        return "QUERIES";
      case ID:
        return "ID";
      case COMMENT:
        return "COMMENT";
      case UNDEFINED:
        return "$";
      case END_OF_INPUT:
        return "END_OF_INPUT";
      default:
        return "UNKNOWN";
    }
  }

  std::string toString() const {
    std::stringstream out;
    out << "(" << typeName() << "," << "\"" << value << "\"" << "," << lineNum << ")";
    return out.str();
  }

  TokenType getType() { return type; }
};